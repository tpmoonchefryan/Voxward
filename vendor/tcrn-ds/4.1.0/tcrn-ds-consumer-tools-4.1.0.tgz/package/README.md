# DS consumer tools 4.1.0

Local unpublished candidate. Install the archive and its exact TypeScript and Playwright runtime dependencies.
Run tcrn-ds-check --project . --index ./producer/ai/index.json --declaration .tcrn-ds.json.
The offline producer AI tree and trusted identity must come from the same candidate.
The CLI bundles the unmodified checker and pure observation validator; inputs/ retains their exact bytes.
Add --layout-url http://127.0.0.1:PORT/page to measure actual action and fill-field geometry at desktop and narrow widths in Chromium. Install the matching browser with npx playwright install chromium when absent.
It does not authenticate reports or replace types, keyboard/focus, API or publication checks.
